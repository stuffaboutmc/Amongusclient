package myau.client.modules.combat;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Keyboard;

public class Reach extends Module {
    private double distance = 4.5;

    public Reach() {
        super("Reach", "Increases attack reach distance", Category.COMBAT, Keyboard.KEY_NONE);
        addSetting(new Setting("Distance", SettingType.NUMBER, 4.5, 3.0, 6.0));
    }

    @Override
    public void onEnable() {
        distance = getSetting("Distance").getDouble();
    }

    @Override
    public void onUpdate() {
        distance = getSetting("Distance").getDouble();
        if (mc.field_71476_x != null && mc.field_71476_x.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY) {
            if (mc.field_71476_x.field_72308_g != null) {
                double dist = mc.field_71439_g.func_70032_d(mc.field_71476_x.field_72308_g);
                if (dist > 3.0 && dist <= distance) {
                    mc.field_71442_b.func_78764_a(mc.field_71439_g, mc.field_71476_x.field_72308_g);
                }
            }
        }
    }
}
