package myau.client.modules.hud;

import myau.client.core.Category;
import myau.client.core.Module;
import org.lwjgl.input.Keyboard;

public class FPS extends Module {
    public FPS() {
        super("FPS", "Shows FPS counter", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D(float partialTicks) {
        if (mc.field_71439_g == null) return;

        int fps = mc.func_175610_ah();
        String text = "FPS: " + fps;
        int color = fps >= 60 ? 0x55FF55 : (fps >= 30 ? 0xFFFF55 : 0xFF5555);
        mc.field_71466_p.func_175063_a(text, 4, 36, color);
    }
}
