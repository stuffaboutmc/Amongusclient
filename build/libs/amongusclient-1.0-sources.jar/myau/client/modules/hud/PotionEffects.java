package myau.client.modules.hud;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

import java.util.Collection;

public class PotionEffects extends Module {
    public PotionEffects() {
        super("PotionEffects", "Shows active potion effects", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D(float partialTicks) {
        if (mc.field_71439_g == null) return;

        Collection<PotionEffect> effects = mc.field_71439_g.func_70651_bq();
        if (effects.isEmpty()) return;

        int y = 46;
        for (PotionEffect effect : effects) {
            Potion potion = Potion.field_76425_a[effect.func_76456_a()];
            String name = potion.func_76393_a();
            int amplifier = effect.func_76458_c();
            int duration = effect.func_76459_b();

            String durationStr = "";
            int seconds = duration / 20;
            if (seconds >= 60) {
                durationStr = (seconds / 60) + "m " + (seconds % 60) + "s";
            } else {
                durationStr = seconds + "s";
            }

            String text = name + " " + roman(amplifier) + " " + durationStr;
            int color = potion.func_76401_j();
            mc.field_71466_p.func_175063_a(text, 4, y, color);
            y += 10;
        }
    }

    private String roman(int level) {
        switch (level) {
            case 0: return "";
            case 1: return "II";
            case 2: return "III";
            case 3: return "IV";
            case 4: return "V";
            default: return String.valueOf(level + 1);
        }
    }
}
