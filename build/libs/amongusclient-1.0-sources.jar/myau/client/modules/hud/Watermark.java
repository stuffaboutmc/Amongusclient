package myau.client.modules.hud;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Keyboard;

public class Watermark extends Module {
    public Watermark() {
        super("Watermark", "Shows client name on screen", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D(float partialTicks) {
        mc.field_71466_p.func_175063_a("among us client", 4, 4, 0xFFFFFF);
    }
}
