package myau.client.modules.movement;

import myau.client.core.Category;
import myau.client.core.Module;
import org.lwjgl.input.Keyboard;

public class Sprint extends Module {

    public Sprint() {
        super("Sprint", "Automatically sprints", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null) return;
        if (mc.field_71439_g.field_70701_bs > 0) {
            mc.field_71439_g.func_70031_b(true);
        }
    }
}
