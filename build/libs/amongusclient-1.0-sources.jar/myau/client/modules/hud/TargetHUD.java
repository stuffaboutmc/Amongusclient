package myau.client.modules.hud;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

public class TargetHUD extends Module {
    private EntityPlayer lastTarget = null;

    public TargetHUD() {
        super("TargetHUD", "Shows target info in combat", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D(float partialTicks) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        EntityPlayer target = findTarget();
        if (target == null) return;

        int centerX = mc.field_71443_c / 8;
        int centerY = mc.field_71440_d / 4;

        Gui.func_73734_a(centerX - 50, centerY - 30, centerX + 50, centerY + 30, 0x80000000);

        mc.field_71466_p.func_175063_a(target.func_70005_c_(), centerX - mc.field_71466_p.func_78256_a(target.func_70005_c_()) / 2, centerY - 20, 0xFFFFFF);
        mc.field_71466_p.func_175063_a("HP: " + String.format("%.1f", target.func_110143_aJ()), centerX - 30, centerY - 5, 0xFF5555);
        mc.field_71466_p.func_175063_a("Dist: " + String.format("%.1f", mc.field_71439_g.func_70032_d(target)), centerX - 30, centerY + 8, 0x55FF55);

        float healthPct = target.func_110143_aJ() / target.func_110138_aP();
        int barWidth = 80;
        int barHeight = 4;
        int barX = centerX - barWidth / 2;
        int barY = centerY + 18;
        Gui.func_73734_a(barX, barY, barX + barWidth, barY + barHeight, 0xFF333333);
        int fillColor = healthPct > 0.5F ? 0xFF00FF00 : (healthPct > 0.25F ? 0xFFFFFF00 : 0xFFFF0000);
        Gui.func_73734_a(barX, barY, barX + (int)(barWidth * healthPct), barY + barHeight, fillColor);
    }

    private EntityPlayer findTarget() {
        EntityPlayer closest = null;
        double closestDist = 6.0;
        for (Object obj : mc.field_71441_e.field_72996_f) {
            if (obj instanceof EntityPlayer && obj != mc.field_71439_g) {
                EntityPlayer p = (EntityPlayer) obj;
                if (p.field_70128_L || p.func_110143_aJ() <= 0) continue;
                double dist = mc.field_71439_g.func_70032_d(p);
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = p;
                }
            }
        }
        return closest;
    }
}
