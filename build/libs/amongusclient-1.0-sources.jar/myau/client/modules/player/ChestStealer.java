package myau.client.modules.player;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.Slot;
import org.lwjgl.input.Keyboard;

public class ChestStealer extends Module {
    private int tickDelay = 0;

    public ChestStealer() {
        super("ChestStealer", "Steals all items from opened chest", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null) return;
        tickDelay++;
        if (tickDelay < 2) return;
        tickDelay = 0;

        if (mc.field_71462_r instanceof GuiChest) {
            GuiChest chest = (GuiChest) mc.field_71462_r;
            ContainerChest container = (ContainerChest) chest.field_147002_h;
            int totalSlots = container.func_85151_d().func_70302_i_();

            for (int i = 0; i < totalSlots; i++) {
                Slot slot = container.func_75139_a(i);
                if (slot != null && slot.func_75211_c() != null && slot.func_75216_d()) {
                    mc.field_71442_b.func_78753_a(container.field_75152_c, i, 0, 1, mc.field_71439_g);
                }
            }
        }
    }
}
