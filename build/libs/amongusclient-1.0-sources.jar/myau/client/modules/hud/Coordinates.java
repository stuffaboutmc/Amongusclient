package myau.client.modules.hud;

import myau.client.core.Category;
import myau.client.core.Module;
import org.lwjgl.input.Keyboard;

public class Coordinates extends Module {
    public Coordinates() {
        super("Coordinates", "Shows XYZ coordinates", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D(float partialTicks) {
        if (mc.field_71439_g == null) return;

        int x = (int) mc.field_71439_g.field_70165_t;
        int y = (int) mc.field_71439_g.field_70163_u;
        int z = (int) mc.field_71439_g.field_70161_v;
        int bx = (int) Math.floor(mc.field_71439_g.field_70165_t);
        int bz = (int) Math.floor(mc.field_71439_g.field_70161_v);

        String text = String.format("XYZ: %d, %d, %d", x, y, z);
        String blockText = String.format("Block: %d, %d", bx, bz);

        mc.field_71466_p.func_175063_a(text, 4, 16, 0xAAAAAA);
        mc.field_71466_p.func_175063_a(blockText, 4, 26, 0x888888);
    }
}
