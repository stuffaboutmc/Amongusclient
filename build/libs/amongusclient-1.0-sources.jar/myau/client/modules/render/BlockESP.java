package myau.client.modules.render;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class BlockESP extends Module {
    private List<Block> targetBlocks = new ArrayList<>();

    public BlockESP() {
        super("BlockESP", "Highlights specific blocks in world", Category.RENDER, Keyboard.KEY_NONE);
        targetBlocks.add(Blocks.field_150482_ag);
        targetBlocks.add(Blocks.field_150352_o);
        targetBlocks.add(Blocks.field_150366_p);
        targetBlocks.add(Blocks.field_150365_q);
        targetBlocks.add(Blocks.field_150412_bA);
        targetBlocks.add(Blocks.field_150369_x);
        targetBlocks.add(Blocks.field_150486_ae);
    }

    @Override
    public void onRender3D(float partialTicks) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        int range = 64;
        int px = (int) mc.field_71439_g.field_70165_t;
        int py = (int) mc.field_71439_g.field_70163_u;
        int pz = (int) mc.field_71439_g.field_70161_v;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);
        GL11.glLineWidth(2.0F);

        for (int x = px - range; x <= px + range; x++) {
            for (int y = py - range; y <= py + range; y++) {
                for (int z = pz - range; z <= pz + range; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
                    if (targetBlocks.contains(block)) {
                        double dx = pos.func_177958_n() - mc.func_175598_ae().field_78730_l;
                        double dy = pos.func_177956_o() - mc.func_175598_ae().field_78731_m;
                        double dz = pos.func_177952_p() - mc.func_175598_ae().field_78728_n;

                        if (block == Blocks.field_150482_ag) GL11.glColor4f(0.0F, 1.0F, 1.0F, 0.5F);
                        else if (block == Blocks.field_150352_o) GL11.glColor4f(1.0F, 1.0F, 0.0F, 0.5F);
                        else if (block == Blocks.field_150412_bA) GL11.glColor4f(0.0F, 1.0F, 0.0F, 0.5F);
                        else if (block == Blocks.field_150486_ae) GL11.glColor4f(1.0F, 0.5F, 0.0F, 0.5F);
                        else GL11.glColor4f(0.8F, 0.8F, 0.8F, 0.5F);

                        AxisAlignedBB bb = new AxisAlignedBB(dx, dy, dz, dx + 1, dy + 1, dz + 1);
                        drawOutlinedBox(bb);
                    }
                }
            }
        }

        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private void drawOutlinedBox(AxisAlignedBB bb) {
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
        GL11.glEnd();
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
        GL11.glEnd();
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
        GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
        GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
        GL11.glEnd();
    }
}
