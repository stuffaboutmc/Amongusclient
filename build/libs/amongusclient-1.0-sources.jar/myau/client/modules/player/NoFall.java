package myau.client.modules.player;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

public class NoFall extends Module {
    public NoFall() {
        super("NoFall", "Cancels fall damage", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null) return;
        if (mc.field_71439_g.field_70143_R > 2.0F) {
            mc.field_71439_g.field_71174_a.func_147297_a(new C03PacketPlayer.C04PacketPlayerPosition(
                mc.field_71439_g.field_70165_t,
                mc.field_71439_g.field_70163_u,
                mc.field_71439_g.field_70161_v,
                mc.field_71439_g.field_70122_E
            ));
        }
    }
}
