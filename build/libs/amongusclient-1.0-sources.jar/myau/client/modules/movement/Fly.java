package myau.client.modules.movement;

import myau.client.core.Category;
import myau.client.core.Module;
import org.lwjgl.input.Keyboard;

public class Fly extends Module {
    private double flySpeed = 2.0;

    public Fly() {
        super("Fly", "Allows creative flying", Category.MOVEMENT, Keyboard.KEY_F);
        addSetting(new Setting("Speed", SettingType.NUMBER, 2.0, 0.5, 10.0));
    }

    @Override
    public void onEnable() {
        if (mc.field_71439_g != null) {
            mc.field_71439_g.field_71075_bZ.field_75100_b = true;
        }
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null) return;
        flySpeed = getSetting("Speed").getDouble();
        mc.field_71439_g.field_71075_bZ.field_75100_b = true;
        mc.field_71439_g.field_71075_bZ.func_75092_a((float)(flySpeed * 0.05));
        mc.field_71439_g.field_70145_X = true;
        mc.field_71439_g.field_70181_x = 0;
        if (mc.field_71474_y.field_74314_A.func_151470_d()) {
            mc.field_71439_g.field_70181_x += flySpeed * 0.5;
        }
        if (mc.field_71474_y.field_74311_E.func_151470_d()) {
            mc.field_71439_g.field_70181_x -= flySpeed * 0.5;
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_71439_g != null) {
            mc.field_71439_g.field_71075_bZ.field_75100_b = false;
            mc.field_71439_g.field_71075_bZ.func_75092_a(0.05F);
            mc.field_71439_g.field_70145_X = false;
        }
    }
}
