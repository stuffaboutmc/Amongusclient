package myau.client.command.commands;
import myau.client.command.Command;
import myau.client.command.CommandManager;
import net.minecraft.client.Minecraft;
public class CoordsCmd extends Command {
    public CoordsCmd() { super("coords"); }
    public void execute(String[] args) {
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71439_g == null) { CommandManager.sendClientMessage("\u00a7cNot in game"); return; }
        int x = (int)mc.field_71439_g.field_70165_t, y = (int)mc.field_71439_g.field_70163_u, z = (int)mc.field_71439_g.field_70161_v;
        CommandManager.sendClientMessage("\u00a7eXYZ: \u00a77" + x + " / " + y + " / " + z);
    }
}
