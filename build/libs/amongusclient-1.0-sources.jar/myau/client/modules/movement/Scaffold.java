package myau.client.modules.movement;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.lwjgl.input.Keyboard;

public class Scaffold extends Module {

    public Scaffold() {
        super("Scaffold", "Places blocks under you", Category.MOVEMENT, Keyboard.KEY_NONE);
        addSetting(new Setting("Mode", SettingType.MODE, "Normal", "Normal", "Fast", "Legit"));
        addSetting(new Setting("Range", SettingType.NUMBER, 4.0, 1.0, 6.0));
        addSetting(new Setting("Swing", SettingType.BOOLEAN, true));
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        BlockPos pos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 1, mc.field_71439_g.field_70161_v);
        if (mc.field_71441_e.func_175623_d(pos)) {
            int slot = getBlockSlot();
            if (slot == -1) return;

            EnumFacing side = getPlaceSide(pos);
            if (side == null) return;

            int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
            mc.field_71439_g.field_71071_by.field_70461_c = slot;

            mc.field_71442_b.func_180511_b(pos, side);
            Setting swingSetting = getSetting("Swing");
            if (swingSetting != null && swingSetting.getBoolean()) {
                mc.field_71439_g.func_71038_i();
            }

            mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
        }
    }

    private int getBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack != null && stack.func_77973_b() instanceof ItemBlock) {
                return i;
            }
        }
        return -1;
    }

    private EnumFacing getPlaceSide(BlockPos pos) {
        for (EnumFacing side : EnumFacing.values()) {
            BlockPos neighbor = pos.func_177972_a(side);
            if (!mc.field_71441_e.func_175623_d(neighbor)) {
                return side.func_176734_d();
            }
        }
        return null;
    }
}
