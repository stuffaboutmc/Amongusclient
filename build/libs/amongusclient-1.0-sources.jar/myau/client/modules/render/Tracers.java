package myau.client.modules.render;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class Tracers extends Module {
    public Tracers() {
        super("Tracers", "Draws lines from crosshair to players", Category.RENDER, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender3D(float partialTicks) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.0F);

        double px = mc.func_175598_ae().field_78730_l;
        double py = mc.func_175598_ae().field_78731_m + mc.field_71439_g.func_70047_e();
        double pz = mc.func_175598_ae().field_78728_n;

        for (Object obj : mc.field_71441_e.field_72996_f) {
            if (obj instanceof EntityPlayer && obj != mc.field_71439_g) {
                EntityPlayer player = (EntityPlayer) obj;
                if (player.field_70128_L || player.func_110143_aJ() <= 0) continue;

                double x = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * partialTicks - px;
                double y = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * partialTicks - py;
                double z = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * partialTicks - pz;

                float dist = (float) Math.sqrt(x * x + y * y + z * z);
                float r = Math.min(1.0F, dist / 64.0F);
                float g = 1.0F - r;

                GL11.glColor4f(r, g, 0.0F, 0.6F);
                GL11.glBegin(GL11.GL_LINES);
                GL11.glVertex3d(0, 0, 0);
                GL11.glVertex3d(x, y, z);
                GL11.glEnd();
            }
        }

        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }
}
