package myau.client.modules.combat;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

public class KillAura extends Module {

    public KillAura() {
        super("KillAura", "Attacks nearby players automatically", Category.COMBAT, Keyboard.KEY_NONE);
        addSetting(new Setting("Range", SettingType.NUMBER, 4.0, 1.0, 8.0));
        addSetting(new Setting("HitDelay", SettingType.BOOLEAN, true));
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;
        Setting rangeSetting = getSetting("Range");
        double range = rangeSetting != null ? rangeSetting.getDouble() : 4.0;
        for (Entity e : mc.field_71441_e.field_72996_f) {
            if (e instanceof EntityPlayer && e != mc.field_71439_g) {
                if (mc.field_71439_g.func_70032_d(e) < range) {
                    mc.field_71442_b.func_78764_a(mc.field_71439_g, e);
                }
            }
        }
    }
}
