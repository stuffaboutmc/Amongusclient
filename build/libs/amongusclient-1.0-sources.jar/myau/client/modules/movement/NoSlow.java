package myau.client.modules.movement;

import myau.client.core.Category;
import myau.client.core.Module;
import org.lwjgl.input.Keyboard;

public class NoSlow extends Module {
    public NoSlow() {
        super("NoSlow", "Prevents item use slowdown", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null) return;
        if (mc.field_71439_g.func_71039_bw()) {
            mc.field_71439_g.field_70159_w *= 1.0;
            mc.field_71439_g.field_70179_y *= 1.0;
        }
    }
}
