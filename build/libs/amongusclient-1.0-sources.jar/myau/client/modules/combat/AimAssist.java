package myau.client.modules.combat;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

public class AimAssist extends Module {
    private int speed = 5;
    private double range = 4.5;
    private int tickCounter = 0;

    public AimAssist() {
        super("AimAssist", "Slowly rotates towards nearest player", Category.COMBAT, Keyboard.KEY_NONE);
        addSetting(new Setting("Speed", SettingType.NUMBER, 5, 1, 10));
        addSetting(new Setting("Range", SettingType.NUMBER, 4.5, 2.0, 6.0));
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        tickCounter++;
        if (tickCounter % 2 != 0) return;

        Entity target = findTarget();
        if (target == null) return;

        float[] targetRot = getRotationsTo(target);
        float yawDiff = targetRot[0] - mc.field_71439_g.field_70177_z;
        float pitchDiff = targetRot[1] - mc.field_71439_g.field_70125_A;

        while (yawDiff > 180) yawDiff -= 360;
        while (yawDiff < -180) yawDiff += 360;

        float factor = speed / 10.0F;
        mc.field_71439_g.field_70177_z += yawDiff * factor;
        mc.field_71439_g.field_70125_A += pitchDiff * factor;
    }

    private Entity findTarget() {
        Entity closest = null;
        double closestDist = range;
        for (Object obj : mc.field_71441_e.field_72996_f) {
            if (obj instanceof EntityPlayer && obj != mc.field_71439_g) {
                EntityPlayer p = (EntityPlayer) obj;
                if (p.field_70128_L || p.func_110143_aJ() <= 0) continue;
                double dist = mc.field_71439_g.func_70032_d(p);
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = p;
                }
            }
        }
        return closest;
    }

    private float[] getRotationsTo(Entity entity) {
        double diffX = entity.field_70165_t - mc.field_71439_g.field_70165_t;
        double diffY = (entity.field_70163_u + entity.func_70047_e()) - (mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e());
        double diffZ = entity.field_70161_v - mc.field_71439_g.field_70161_v;
        double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, dist));
        return new float[]{yaw, pitch};
    }
}
