package myau.client.modules.hud;

import myau.client.core.Category;
import myau.client.core.Module;
import myau.client.core.ModuleManager;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ArrayListMod extends Module {
    public ArrayListMod() {
        super("ArrayList", "Shows enabled modules on screen", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D(float partialTicks) {
        List<Module> enabled = new ArrayList<>();
        for (Module m : ModuleManager.getModules()) {
            if (m.isEnabled() && m.getCategory() != Category.MISC) {
                enabled.add(m);
            }
        }

        enabled.sort(new Comparator<Module>() {
            @Override
            public int compare(Module a, Module b) {
                return mc.field_71466_p.func_78256_a(b.getName()) - mc.field_71466_p.func_78256_a(a.getName());
            }
        });

        int y = 2;
        int x = mc.field_71443_c / 2 - 1;

        for (Module m : enabled) {
            String name = m.getName();
            int color = m.getCategory().color;
            mc.field_71466_p.func_175063_a(name, x - mc.field_71466_p.func_78256_a(name), y, color);
            y += mc.field_71466_p.field_78288_b + 2;
        }
    }
}
