package myau.client.modules.combat;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Keyboard;

public class AutoSword extends Module {
    public AutoSword() {
        super("AutoSword", "Switches to best sword in hotbar", Category.COMBAT, Keyboard.KEY_NONE);
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        int bestSlot = -1;
        float bestDamage = 0;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack != null && stack.func_77973_b() instanceof ItemSword) {
                ItemSword sword = (ItemSword) stack.func_77973_b();
                float damage = sword.func_150931_i();
                if (damage > bestDamage) {
                    bestDamage = damage;
                    bestSlot = i;
                }
            }
        }

        if (bestSlot != -1 && mc.field_71439_g.field_71071_by.field_70461_c != bestSlot) {
            mc.field_71439_g.field_71071_by.field_70461_c = bestSlot;
        }
    }
}
