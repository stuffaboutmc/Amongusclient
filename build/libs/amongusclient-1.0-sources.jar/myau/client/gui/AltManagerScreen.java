package myau.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import myau.client.alt.AltManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.List;

public class AltManagerScreen extends GuiScreen {

    private GuiTextField usernameField;
    private int panelX, panelY, panelW = 400, panelH = 300;
    private int scrollOffset = 0;
    private int maxScroll = 0;
    private int hoveredIndex = -1;
    private int mouseX, mouseY;
    private String statusMessage = "";
    private int statusTimer = 0;

    @Override
    public void func_73866_w_() {
        super.func_73866_w_();
        Keyboard.enableRepeatEvents(true);
        ScaledResolution sr = new ScaledResolution(field_146297_k);
        int sw = sr.func_78326_a();
        int sh = sr.func_78328_b();
        panelX = sw / 2 - panelW / 2;
        panelY = sh / 2 - panelH / 2;

        usernameField = new GuiTextField(0, field_146297_k.field_71466_p, panelX + 20, panelY + 40, panelW - 40, 20);
        usernameField.func_146203_f(32);
        usernameField.func_146195_b(true);
        usernameField.func_146185_a(true);
        usernameField.func_146180_a("");
        updateMaxScroll();
    }

    private void updateMaxScroll() {
        List<AltManager.AltEntry> alts = AltManager.getAlts();
        int contentH = alts.size() * 26;
        int visibleH = panelH - 120;
        maxScroll = Math.max(0, contentH - visibleH);
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.mouseX = mouseX;
        this.mouseY = mouseY;

        ScaledResolution sr = new ScaledResolution(field_146297_k);
        int sw = sr.func_78326_a();
        int sh = sr.func_78328_b();
        panelX = sw / 2 - panelW / 2;
        panelY = sh / 2 - panelH / 2;

        ClickGuiRenderer.drawRect(0, 0, sw, sh, 0xCC000000);

        drawRoundedRect(panelX, panelY, panelW, panelH, 10, 0xE01A1A1A);

        if (statusTimer > 0) {
            statusTimer--;
            int statusAlpha = Math.min(255, statusTimer * 4);
            field_146297_k.field_71466_p.func_175063_a(statusMessage,
                sw / 2f - field_146297_k.field_71466_p.func_78256_a(statusMessage) / 2f,
                panelY + panelH + 8, (statusAlpha << 24) | 0xFF44FF44);
        }

        field_146297_k.field_71466_p.func_175063_a("ALT MANAGER",
            sw / 2f - field_146297_k.field_71466_p.func_78256_a("ALT MANAGER") / 2f,
            panelY + 14, 0xFFE60000);

        if (usernameField != null) {
            usernameField.field_146209_f = panelX + 20;
            usernameField.field_146210_g = panelY + 40;
            usernameField.func_146194_f();
        }

        int addBtnX = panelX + panelW - 70;
        int addBtnY = panelY + 38;
        int addBtnW = 50;
        int addBtnH = 22;
        boolean addHovered = mouseX >= addBtnX && mouseX <= addBtnX + addBtnW
            && mouseY >= addBtnY && mouseY <= addBtnY + addBtnH;
        drawRoundedRect(addBtnX, addBtnY, addBtnW, addBtnH, 4, addHovered ? 0xFFE60000 : 0xFFAA0000);
        field_146297_k.field_71466_p.func_175063_a("Add",
            addBtnX + addBtnW / 2f - field_146297_k.field_71466_p.func_78256_a("Add") / 2f,
            addBtnY + 7, 0xFFFFFFFF);

        List<AltManager.AltEntry> alts = AltManager.getAlts();
        int contentY = panelY + 68;
        int contentH = panelH - 110;
        hoveredIndex = -1;

        GlStateManager.func_179147_l();
        ScaledResolution clipSr = new ScaledResolution(field_146297_k);
        float scale = clipSr.func_78325_e();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        org.lwjgl.opengl.GL11.glScissor(
            (int) ((panelX + 4) * scale),
            (int) ((sh / clipSr.func_78325_e() - (contentY + contentH)) * scale),
            (int) ((panelW - 8) * scale),
            (int) (contentH * scale)
        );

        for (int i = 0; i < alts.size(); i++) {
            int rowY = contentY + i * 26 - scrollOffset;
            if (rowY + 26 < contentY || rowY > contentY + contentH) continue;

            AltManager.AltEntry entry = alts.get(i);
            boolean rowHovered = mouseX >= panelX + 10 && mouseX <= panelX + panelW - 10
                && mouseY >= rowY && mouseY <= rowY + 22;
            if (rowHovered) hoveredIndex = i;

            int rowBg = rowHovered ? 0xFF2A2A2A : 0xFF222222;
            drawRoundedRect(panelX + 10, rowY, panelW - 20, 22, 4, rowBg);

            field_146297_k.field_71466_p.func_175063_a(entry.name != null ? entry.name : "Unknown",
                panelX + 18, rowY + 7, entry.cracked ? 0xFFAAAAAA : 0xFFFFFFFF);

            int loginBtnX = panelX + panelW - 140;
            int loginBtnW = 50;
            boolean loginHovered = mouseX >= loginBtnX && mouseX <= loginBtnX + loginBtnW
                && mouseY >= rowY + 3 && mouseY <= rowY + 19;
            drawRoundedRect(loginBtnX, rowY + 3, loginBtnW, 16, 3, loginHovered ? 0xFF228822 : 0xFF1A6B1A);
            field_146297_k.field_71466_p.func_175063_a("Login",
                loginBtnX + loginBtnW / 2f - field_146297_k.field_71466_p.func_78256_a("Login") / 2f,
                rowY + 7, 0xFFFFFFFF);

            int removeBtnX = panelX + panelW - 80;
            int removeBtnW = 50;
            boolean removeHovered = mouseX >= removeBtnX && mouseX <= removeBtnX + removeBtnW
                && mouseY >= rowY + 3 && mouseY <= rowY + 19;
            drawRoundedRect(removeBtnX, rowY + 3, removeBtnW, 16, 3, removeHovered ? 0xFFCC2222 : 0xFF881111);
            field_146297_k.field_71466_p.func_175063_a("Remove",
                removeBtnX + removeBtnW / 2f - field_146297_k.field_71466_p.func_78256_a("Remove") / 2f,
                rowY + 7, 0xFFFFFFFF);
        }

        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        int backBtnX = panelX + 10;
        int backBtnY = panelY + panelH - 36;
        int backBtnW = 70;
        int backBtnH = 24;
        boolean backHovered = mouseX >= backBtnX && mouseX <= backBtnX + backBtnW
            && mouseY >= backBtnY && mouseY <= backBtnY + backBtnH;
        drawRoundedRect(backBtnX, backBtnY, backBtnW, backBtnH, 4, backHovered ? 0xFF444444 : 0xFF333333);
        field_146297_k.field_71466_p.func_175063_a("Back",
            backBtnX + backBtnW / 2f - field_146297_k.field_71466_p.func_78256_a("Back") / 2f,
            backBtnY + 8, 0xFFAAAAAA);

        String countStr = alts.size() + " alt(s)";
        field_146297_k.field_71466_p.func_175063_a(countStr,
            panelX + panelW - field_146297_k.field_71466_p.func_78256_a(countStr) - 14,
            panelY + panelH - 30, 0xFF666666);

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private void drawRoundedRect(int x, int y, int w, int h, int r, int color) {
        ClickGuiRenderer.drawRect(x + r, y, x + w - r, y + h, color);
        ClickGuiRenderer.drawRect(x, y + r, x + w, y + h - r, color);
        ClickGuiRenderer.drawRect(x, y, x + r, y + r, color);
        ClickGuiRenderer.drawRect(x + w - r, y, x + w, y + r, color);
        ClickGuiRenderer.drawRect(x, y + h - r, x + r, y + h, color);
        ClickGuiRenderer.drawRect(x + w - r, y + h - r, x + w, y + h, color);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);

        if (usernameField != null) {
            usernameField.func_146192_a(mouseX, mouseY, mouseButton);
        }

        if (mouseButton != 0) return;

        List<AltManager.AltEntry> alts = AltManager.getAlts();

        int contentY = panelY + 68;
        for (int i = 0; i < alts.size(); i++) {
            int rowY = contentY + i * 26 - scrollOffset;

            int loginBtnX = panelX + panelW - 140;
            int loginBtnW = 50;
            if (mouseX >= loginBtnX && mouseX <= loginBtnX + loginBtnW
                && mouseY >= rowY + 3 && mouseY <= rowY + 19) {
                loginAlt(i);
                return;
            }

            int removeBtnX = panelX + panelW - 80;
            int removeBtnW = 50;
            if (mouseX >= removeBtnX && mouseX <= removeBtnX + removeBtnW
                && mouseY >= rowY + 3 && mouseY <= rowY + 19) {
                AltManager.remove(i);
                updateMaxScroll();
                scrollOffset = Math.min(scrollOffset, maxScroll);
                showStatus("Alt removed");
                return;
            }
        }

        int addBtnX = panelX + panelW - 70;
        int addBtnY = panelY + 38;
        int addBtnW = 50;
        int addBtnH = 22;
        if (mouseX >= addBtnX && mouseX <= addBtnX + addBtnW
            && mouseY >= addBtnY && mouseY <= addBtnY + addBtnH) {
            addAlt();
            return;
        }

        int backBtnX = panelX + 10;
        int backBtnY = panelY + panelH - 36;
        int backBtnW = 70;
        int backBtnH = 24;
        if (mouseX >= backBtnX && mouseX <= backBtnX + backBtnW
            && mouseY >= backBtnY && mouseY <= backBtnY + backBtnH) {
            field_146297_k.func_147108_a(new MainMenu());
            return;
        }
    }

    private void addAlt() {
        String username = usernameField != null ? usernameField.func_146179_b().trim() : "";
        if (username.isEmpty()) {
            showStatus("Enter a username");
            return;
        }
        AltManager.add(username, "", true);
        usernameField.func_146180_a("");
        updateMaxScroll();
        showStatus("Added: " + username);
    }

    private void loginAlt(int index) {
        List<AltManager.AltEntry> alts = AltManager.getAlts();
        if (index < 0 || index >= alts.size()) return;
        AltManager.AltEntry entry = alts.get(index);
        String newUsername = entry.name;
        try {
            net.minecraft.client.Minecraft mcInst = Minecraft.func_71410_x();
            net.minecraft.util.Session session = mcInst.func_110432_I();

            java.lang.reflect.Field usernameField = null;
            String[] fieldNames = {"field_74286_b", "username", "field_146421_c", "playerUsername"};
            for (String name : fieldNames) {
                try {
                    usernameField = net.minecraft.util.Session.class.getDeclaredField(name);
                    break;
                } catch (NoSuchFieldException ignored) {}
            }

            if (usernameField == null) {
                showStatus("Could not find username field");
                return;
            }

            usernameField.setAccessible(true);

            try {
                java.lang.reflect.Field modifiersField = java.lang.reflect.Field.class.getDeclaredField("modifiers");
                modifiersField.setAccessible(true);
                modifiersField.setInt(usernameField, usernameField.getModifiers() & ~java.lang.reflect.Modifier.FINAL);
            } catch (Exception ignored) {}

            usernameField.set(session, newUsername);
            showStatus("Logged in as: " + newUsername + " (rejoin to apply)");
        } catch (Exception e) {
            showStatus("Login failed: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private void showStatus(String msg) {
        statusMessage = msg;
        statusTimer = 100;
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (usernameField != null && usernameField.func_146206_l()) {
            usernameField.func_146201_a(typedChar, keyCode);
        }
        if (keyCode == Keyboard.KEY_ESCAPE) {
            field_146297_k.func_147108_a(new MainMenu());
        }
    }

    @Override
    public void func_146274_d() throws IOException {
        super.func_146274_d();
        int dWheel = org.lwjgl.input.Mouse.getDWheel();
        if (dWheel != 0) {
            scrollOffset -= dWheel > 0 ? 26 : -26;
            scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset));
        }
    }

    @Override
    public void func_73876_c() {
        super.func_73876_c();
        if (usernameField != null) {
            usernameField.func_146178_a();
        }
    }

    @Override
    public void func_146281_b() {
        super.func_146281_b();
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }
}
