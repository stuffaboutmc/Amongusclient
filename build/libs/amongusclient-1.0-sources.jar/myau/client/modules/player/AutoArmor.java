package myau.client.modules.player;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Keyboard;

public class AutoArmor extends Module {
    private int tickCounter = 0;

    public AutoArmor() {
        super("AutoArmor", "Auto equips best armor from inventory", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;
        tickCounter++;
        if (tickCounter < 5) return;
        tickCounter = 0;

        for (int armorType = 0; armorType < 4; armorType++) {
            ItemStack currentArmor = mc.field_71439_g.field_71071_by.field_70460_b[armorType];
            int currentProtection = getProtection(currentArmor);

            int bestSlot = -1;
            int bestProtection = currentProtection;

            for (int i = 9; i < 36; i++) {
                ItemStack stack = mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
                if (stack != null && stack.func_77973_b() instanceof ItemArmor) {
                    ItemArmor armor = (ItemArmor) stack.func_77973_b() ;
                    if (armor.field_77881_a == armorType) {
                        int prot = getProtection(stack);
                        if (prot > bestProtection) {
                            bestProtection = prot;
                            bestSlot = i;
                        }
                    }
                }
            }

            if (bestSlot != -1) {
                mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71069_bz.field_75152_c, bestSlot, 0, 1, mc.field_71439_g);
            }
        }
    }

    private int getProtection(ItemStack stack) {
        if (stack == null || !(stack.func_77973_b() instanceof ItemArmor)) return -1;
        ItemArmor armor = (ItemArmor) stack.func_77973_b();
        return armor.field_77879_b;
    }
}
