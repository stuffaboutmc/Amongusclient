package myau.client.modules.render;

import myau.client.core.Category;
import myau.client.core.Module;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class NameTags extends Module {
    public NameTags() {
        super("NameTags", "Enhanced name tags with health info", Category.RENDER, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender3D(float partialTicks) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        for (Object obj : mc.field_71441_e.field_72996_f) {
            if (obj instanceof EntityPlayer && obj != mc.field_71439_g) {
                EntityPlayer player = (EntityPlayer) obj;
                if (player.field_70128_L || player.func_110143_aJ() <= 0) continue;
                if (mc.field_71439_g.func_70032_d(player) > 64) continue;

                double x = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * partialTicks - mc.func_175598_ae().field_78730_l;
                double y = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * partialTicks - mc.func_175598_ae().field_78731_m;
                double z = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * partialTicks - mc.func_175598_ae().field_78728_n;

                float health = player.func_110143_aJ();
                float absorption = player.func_110139_bj();

                String name = player.func_70005_c_();
                String healthStr = EnumChatFormatting.RED + " " + String.format("%.1f", health);
                if (absorption > 0) {
                    healthStr += EnumChatFormatting.YELLOW + "+" + String.format("%.1f", absorption);
                }

                String display = name + healthStr;
                float scale = 0.025F;
                float dist = (float) mc.field_71439_g.func_70032_d(player);
                scale *= dist;
                if (scale < 0.01F) scale = 0.01F;
                if (scale > 0.06F) scale = 0.06F;

                GL11.glPushMatrix();
                GL11.glTranslated(x, y + 2.2, z);
                GL11.glRotatef(-mc.func_175598_ae().field_78735_i, 0, 1, 0);
                GL11.glRotatef(mc.func_175598_ae().field_78732_j, 1, 0, 0);
                GL11.glScalef(scale, -scale, scale);

                GlStateManager.func_179097_i();
                GlStateManager.func_179140_f();

                int textWidth = mc.field_71466_p.func_78256_a(display) / 2;
                GlStateManager.func_179090_x();
                GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.4F);
                GL11.glBegin(GL11.GL_QUADS);
                GL11.glVertex3d(-textWidth - 1, -1, 0);
                GL11.glVertex3d(textWidth + 1, -1, 0);
                GL11.glVertex3d(textWidth + 1, 9, 0);
                GL11.glVertex3d(-textWidth - 1, 9, 0);
                GL11.glEnd();
                GlStateManager.func_179098_w();

                mc.field_71466_p.func_175063_a(display, -textWidth, -1, 0xFFFFFF);

                GlStateManager.func_179126_j();
                GlStateManager.func_179145_e();
                GL11.glPopMatrix();
            }
        }
    }
}
