package myau.client.modules.combat;

import myau.client.core.Category;
import myau.client.core.Module;
import org.lwjgl.input.Keyboard;

public class Velocity extends Module {
    private double horizontal = 0.0;
    private double vertical = 0.0;

    public Velocity() {
        super("Velocity", "Reduces knockback from attacks", Category.COMBAT, Keyboard.KEY_NONE);
        addSetting(new Setting("Horizontal", SettingType.NUMBER, 0.0, 0.0, 100.0));
        addSetting(new Setting("Vertical", SettingType.NUMBER, 0.0, 0.0, 100.0));
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null) return;
        if (mc.field_71439_g.field_70737_aN > 0) {
            mc.field_71439_g.field_70159_w *= horizontal / 100.0;
            mc.field_71439_g.field_70179_y *= horizontal / 100.0;
            mc.field_71439_g.field_70181_x *= vertical / 100.0;
        }
    }
}
